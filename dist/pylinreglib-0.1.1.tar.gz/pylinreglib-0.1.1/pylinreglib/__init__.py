from .base import BaseLRM
from .lineal_model import lrm
from .categorical_model import clrm
from .mixed_model import mlrm